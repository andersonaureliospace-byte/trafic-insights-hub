import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { OPERATIONAL_STANDBY } from "@/lib/estrategia/auditorias/config";

// Etapa 257: telas do Hub operacional em standby — abrem o Hub estratégico. Configurações (Meta/WhatsApp) continua aberta.
const STANDBY_PREFIXES = ["/painel", "/mensagens", "/auditoria", "/foco", "/crm", "/corrida"];

// Rotas que não exigem login.
// Etapa 221: /sw.js e /manifest.webmanifest são do app no celular e precisam abrir sem login.
const PUBLIC_PATHS = ["/login", "/esqueci-senha", "/redefinir-senha", "/sw.js", "/manifest.webmanifest"];
const isPublicApi = (pathname: string) =>
  pathname.startsWith("/c/") ||
  pathname.startsWith("/pop/") || // Etapa 241: POP público pra equipe
  pathname.startsWith("/api/public") ||
  pathname.startsWith("/auth/callback");

export async function proxy(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;
  const isPublicPath = PUBLIC_PATHS.includes(pathname) || isPublicApi(pathname);

  if (!user && !isPublicPath) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }

  if (user && OPERATIONAL_STANDBY && STANDBY_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`))) {
    const url = request.nextUrl.clone();
    url.pathname = "/estrategia/trafego";
    url.search = "";
    return NextResponse.redirect(url);
  }

  if (user && pathname === "/login") {
    const url = request.nextUrl.clone();
    url.pathname = "/estrategia/trafego"; // Etapa 238: Hub estratégico é a tela inicial
    return NextResponse.redirect(url);
  }

  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
