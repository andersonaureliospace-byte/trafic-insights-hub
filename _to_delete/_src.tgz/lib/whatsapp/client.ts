// Cliente cru da API do uazapi. Portado do app anterior
// (src/lib/whatsapp.functions.ts / workspace-whatsapps.functions.ts), sem a
// camada de workspace — aqui é sempre a instância única do usuário.

export interface WhatsappCreds {
  api_url: string;
  token: string;
}

export async function waFetch<T>(
  creds: WhatsappCreds,
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const url = `${creds.api_url.replace(/\/+$/, "")}${path}`;
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", token: creds.token, ...(init.headers ?? {}) },
  });
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = text;
  }
  if (!res.ok) {
    const msg =
      (json && typeof json === "object" && "error" in json
        ? String((json as { error: unknown }).error)
        : typeof json === "string"
          ? json
          : text) || `HTTP ${res.status}`;
    throw new Error(`uazapi ${res.status}: ${msg}`);
  }
  return json as T;
}

export interface WhatsappConnectResult {
  qrcode: string | null;
  paircode: string | null;
  status: string;
  connected: boolean;
}

export function extractConnect(json: unknown): WhatsappConnectResult {
  const root = (json ?? {}) as Record<string, unknown>;
  const instance = ((root.instance ?? root) as Record<string, unknown>) || {};
  const status = (instance.status as string) || (root.status as string) || "unknown";
  const qrcode =
    (instance.qrcode as string) ||
    (root.qrcode as string) ||
    (instance.qr as string) ||
    (root.qr as string) ||
    null;
  const paircode =
    (instance.paircode as string) ||
    (root.paircode as string) ||
    (instance.code as string) ||
    (root.code as string) ||
    null;
  return {
    qrcode: qrcode || null,
    paircode: paircode || null,
    status,
    connected: status === "connected" || status === "open",
  };
}

export async function sendText(creds: WhatsappCreds, groupId: string, text: string): Promise<void> {
  await waFetch(creds, "/send/text", {
    method: "POST",
    body: JSON.stringify({ number: groupId, text }),
  });
}

export type WhatsappMediaType = "image" | "video" | "audio" | "document";

export function mediaTypeFromMime(mime: string): WhatsappMediaType {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return "document";
}

// uazapi: POST /send/media — contrato assumido por analogia com /send/text
// (não verificado contra a documentação real; confirmar no primeiro teste).
export async function sendMedia(
  creds: WhatsappCreds,
  groupId: string,
  media: { url: string; type: WhatsappMediaType; caption?: string; fileName?: string },
): Promise<void> {
  await waFetch(creds, "/send/media", {
    method: "POST",
    body: JSON.stringify({
      number: groupId,
      type: media.type,
      file: media.url,
      text: media.caption ?? "",
      docName: media.fileName ?? "",
    }),
  });
}

export interface WhatsappGroup {
  id: string;
  name: string;
}

// Bug corrigido: POST /group/list da uazapi é PAGINADO (limit/offset) — a
// versão antiga pedia só uma página (sem limit/offset), então qualquer
// instância com mais grupos que o tamanho de uma página perdia o resto em
// silêncio (sem erro, "Atualizar grupos" não resolvia porque o problema
// nunca foi cache, e sim faltar pedir as páginas seguintes). Agora pagina
// até uma página vir com menos itens que o limite pedido.
const GROUP_PAGE_SIZE = 100;
const GROUP_MAX_PAGES = 50; // trava de segurança (até 5.000 grupos)

export async function listGroups(creds: WhatsappCreds, force = false): Promise<WhatsappGroup[]> {
  const seen = new Set<string>();
  const groups: WhatsappGroup[] = [];

  for (let page = 0; page < GROUP_MAX_PAGES; page++) {
    const json = await waFetch<unknown>(creds, "/group/list", {
      method: "POST",
      body: JSON.stringify({ force, limit: GROUP_PAGE_SIZE, offset: page * GROUP_PAGE_SIZE, noParticipants: true }),
    });
    const arr: unknown[] = Array.isArray(json)
      ? json
      : Array.isArray((json as { groups?: unknown[] })?.groups)
        ? (json as { groups: unknown[] }).groups
        : Array.isArray((json as { data?: unknown[] })?.data)
          ? (json as { data: unknown[] }).data
          : [];

    for (const g of arr) {
      const o = g as Record<string, unknown>;
      const id = (o.JID as string) || (o.id as string) || (o.wa_chatid as string) || "";
      const name =
        (o.Name as string) ||
        (o.name as string) ||
        (o.Subject as string) ||
        (o.subject as string) ||
        (o.wa_name as string) ||
        id;
      if (id && id.includes("@g.us") && !seen.has(id)) {
        seen.add(id);
        groups.push({ id, name });
      }
    }

    if (arr.length < GROUP_PAGE_SIZE) break; // última página
  }

  groups.sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  return groups;
}
