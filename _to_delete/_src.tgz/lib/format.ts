export function fmtCurrency(value: number | null | undefined, currency = "BRL"): string {
  if (value == null || Number.isNaN(value)) return "—";
  try {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(value);
  } catch {
    return `${currency} ${value.toFixed(2)}`;
  }
}

// Mesmo formato do fmtCurrency, mas sempre com o sinal + ou - na frente —
// usado nas dicas (title) de diferença, ex.: "Invest. diário − Ritmo" ou
// "CPA ideal − CPA", pra deixar claro se está acima ou abaixo sem precisar
// decorar a ordem da subtração.
export function fmtCurrencySigned(value: number | null | undefined, currency = "BRL"): string {
  if (value == null || Number.isNaN(value)) return "—";
  const sign = value < 0 ? "-" : "+";
  return `${sign}${fmtCurrency(Math.abs(value), currency)}`;
}

export const DATE_PRESETS = [
  { id: "last_3d_plus_today", label: "Últimos 3 dias + hoje" },
  { id: "today", label: "Hoje" },
  { id: "yesterday", label: "Ontem" },
  // Etapa 47: já existia pronto no cliente da Graph API (lib/meta/client.ts,
  // portado do app anterior) mas nunca tinha entrado em nenhum filtro da
  // tela — só faltava esse item na lista.
  { id: "today_yesterday", label: "Ontem e hoje" },
  { id: "last_3d", label: "Últimos 3 dias" },
  { id: "last_7d", label: "Últimos 7 dias" },
  { id: "this_month", label: "Mês atual" },
  // Etapa 64: mesma ideia do "Mês atual", mas sem o dia de hoje (ainda em
  // andamento) — do dia 01 até ontem, os dois já fechados.
  { id: "this_month_until_yesterday", label: "Este mês, até ontem" },
] as const;

export type PresetId = (typeof DATE_PRESETS)[number]["id"];

// Etapa 79: "Tipo de conta" de Controle de Saldo — define em qual sub-aba
// (Pix/Híbrida/Boleto/Cartão) cada conta aparece. Antes era
// prepaid/hybrid/postpaid/own_store (ver supabase/migrations/0024_*); agora
// é escolhido manualmente pelo usuário, sem sincronização automática com a
// Meta (Pós-paga misturava Boleto e Cartão sem distinguir — não dava pra
// saber automaticamente qual dos dois).
export const PAYMENT_TYPES = [
  { id: "pix", label: "Pix" },
  { id: "hybrid", label: "Híbrida" },
  { id: "boleto", label: "Boleto" },
  { id: "card", label: "Cartão" },
] as const;

export interface PriorityOption {
  id: string;
  label: string;
  color: string;
}

// Os 5 IDs abaixo são fixos — a classificação automática (atualização de
// status em massa) e o isInauguracao() dependem deles por valor. O que dá
// pra personalizar em Configurações > Status é só o rótulo e a cor (ver
// lib/priority-context.tsx) — a lista de IDs em si nunca muda.
export const DEFAULT_PRIORITY_OPTIONS: PriorityOption[] = [
  { id: "inauguracao", label: "Inauguração", color: "#38bdf8" },
  { id: "baixa", label: "Baixa", color: "#22c55e" },
  { id: "media", label: "Média", color: "#eab308" },
  { id: "alta", label: "Alta", color: "#f97316" },
  { id: "critica", label: "Crítica", color: "#ef4444" },
];

// Mantido pelo nome antigo pra quem só precisa dos rótulos padrão (ex.: a
// classificação automática, que sempre raciocina em cima dos IDs fixos).
export const PRIORITY_OPTIONS = DEFAULT_PRIORITY_OPTIONS;

// Etapa 98: ordem de prioridade usada na ordenação de Acompanhamento e no reordenar do
// "Atualizar status em massa": Inauguração, Crítica, Alta, Média, Baixa; quem ainda não
// tem prioridade fica por último.
const PRIORITY_RANK: Record<string, number> = { inauguracao: 0, critica: 1, alta: 2, media: 3, baixa: 4 };
export function priorityRank(priority: string | null | undefined): number {
  if (priority == null) return 5;
  return PRIORITY_RANK[priority] ?? 5;
}

export function isInauguracao(priority: string | null | undefined): boolean {
  return priority === "inauguracao";
}
