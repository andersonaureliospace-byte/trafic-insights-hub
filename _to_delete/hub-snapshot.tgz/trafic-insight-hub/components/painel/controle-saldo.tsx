"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { fmtCacheTime, isFresh, readTabCache, writeTabCache } from "@/lib/client-cache";
import type { AdAccount, AccountInsight } from "@/lib/meta/insights";
import { fmtCurrency, PAYMENT_TYPES } from "@/lib/format";
import { billingHubUrl } from "@/lib/meta/ads-manager-link";
import { availableFunds } from "@/lib/meta/funds";
import { PersonalizarAlertasPanel, type PixRow, type PixPatch } from "@/components/painel/personalizar-alertas-dialog";
import { EnviarPixDialog } from "@/components/painel/enviar-pix-dialog";

export type { PixRow, PixPatch };

interface BalanceStatus {
  ad_account_id: string;
  balance: number;
  currency: string;
  threshold: number;
  low: boolean;
}

interface FridayBalanceStatus {
  ad_account_id: string;
  balance: number;
  currency: string;
  multiplier: number;
  fridayThreshold: number;
  applicable: boolean;
  low: boolean;
}

interface PaymentStatus {
  ad_account_id: string;
  reason: string | null;
  hasError: boolean;
}

interface Reason {
  key: string;
  label: string;
  tone: "red" | "amber";
}

interface BoletoSend {
  id: string;
  ad_account_id: string;
  client_name: string;
  due_date: string;
  pdf_file_name: string;
  status: string;
  error: string | null;
  created_at: string;
}

interface PixSend {
  id: string;
  ad_account_id: string;
  client_name: string;
  target_type: string;
  target_label: string;
  scheduled_at: string | null;
  status: string;
  error: string | null;
  created_at: string;
}

interface Row {
  acc: AdAccount;
  reasons: Reason[];
}

// Etapa 79: sub-abas de Controle de Saldo — Pendências primeiro (é o mais
// urgente de ver ao entrar na tela), depois um subgrupo por Tipo de conta
// (Pix/Híbrida/Boleto/Cartão, nessa ordem — pedido explícito), e
// Configurações por último (onde toda conta é classificada e o resto das
// rotinas de alerta é ajustado).
type TabId = "pendencias" | "pix" | "hybrid" | "boleto" | "card" | "config";
const TABS: { id: TabId; label: string }[] = [
  { id: "pendencias", label: "⚠️ Pendências" },
  ...PAYMENT_TYPES.map((t) => ({ id: t.id as TabId, label: t.label })),
  { id: "config", label: "Configurações" },
];

// Ação disponível na coluna "Ação" de cada conta — decidida pelo próprio
// Tipo de conta dela (Etapa 79: "enviar Pix" só pra Pix/Híbrida, "enviar
// boleto" só pra Boleto, Cartão não tem ação específica nenhuma) — mesma
// regra vale tanto dentro do subgrupo do próprio tipo quanto misturada em
// Pendências.
function fmtDateBR(iso: string | null | undefined): string {
  if (!iso) return "—";
  const [y, m, d] = iso.slice(0, 10).split("-");
  return y && m && d ? `${d}/${m}/${y}` : iso;
}

function actionForType(type: string | null | undefined): "pix" | "boleto" | "none" {
  if (type === "pix" || type === "hybrid") return "pix";
  if (type === "boleto") return "boleto";
  return "none";
}

// Tabela reaproveitada pelas 5 sub-abas que listam contas (Pendências,
// Pix, Híbrida, Boleto, Cartão) — só muda o conjunto de linhas e a
// mensagem de "lista vazia"; a ação de cada linha (Enviar Pix/Enviar
// boleto/nenhuma) é sempre derivada do Tipo de conta daquela linha.
function ContasTable({
  rows,
  insights,
  clientNames,
  pixByAccount,
  emptyMessage,
  onOpenPix,
  onOpenBoleto,
}: {
  rows: Row[];
  insights: Record<string, AccountInsight>;
  clientNames: Record<string, string>;
  pixByAccount: Record<string, PixRow>;
  emptyMessage: string;
  onOpenPix: (acc: AdAccount) => void;
  onOpenBoleto: (accountId: string) => void;
}) {
  if (rows.length === 0) {
    return <p className="px-4 py-6 text-sm text-zinc-500">{emptyMessage}</p>;
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wide text-zinc-400">
            <th className="px-4 py-1.5 font-medium">Cliente</th>
            <th className="px-4 py-1.5 font-medium">Conta</th>
            <th
              className="px-4 py-1.5 text-right font-medium"
              title={
                'Pix/Híbrida com teto de gasto na Meta: quanto ainda dá pra gastar antes de precisar recarregar ' +
                '("disponível", cai com o uso). Boleto/Cartão (sem teto, cobrado depois): valor acumulado desde a ' +
                'última cobrança — cresce com o uso, não é dinheiro que sobra ("a pagar").'
              }
            >
              Saldo
            </th>
            <th
              className="px-4 py-1.5 text-right font-medium"
              title="Orçamento diário atual dos conjuntos/campanhas ativos (mesmo dado de Acompanhamento)"
            >
              Invest. diário
            </th>
            <th className="px-4 py-1.5 font-medium">Avisos</th>
            <th className="px-4 py-1.5 font-medium">Observação</th>
            <th className="px-4 py-1.5 font-medium">Ação</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(({ acc, reasons }) => {
            const funds = availableFunds(acc);
            const pix = pixByAccount[acc.account_id];
            const notes = pix?.notes;
            const action = actionForType(pix?.payment_type);
            return (
              <tr key={acc.id} className="border-t border-zinc-100 align-top dark:border-zinc-800/60">
                <td className="px-4 py-2 font-medium text-zinc-900 dark:text-zinc-50">
                  {clientNames[acc.account_id] ?? acc.name}
                </td>
                <td className="px-4 py-2">
                  <a
                    href={billingHubUrl(acc.account_id, acc.business?.id)}
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Abrir Cobranças e Pagamentos"
                    className="text-zinc-500 underline decoration-dotted underline-offset-2 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100"
                  >
                    {acc.name}
                  </a>
                </td>
                {pix?.funds_balance_enabled ? (
                  <td
                    className="px-4 py-2 text-right tabular-nums"
                    title={
                      "Saldo por fundos (Etapa 81): rastreado à parte do cálculo padrão — começa de um saldo " +
                      "inicial informado manualmente e, a partir daí, soma pagamento manual/PIX e subtrai cobrança " +
                      "da Meta. " +
                      (pix.funds_balance_updated_at
                        ? `Atualizado em ${new Date(pix.funds_balance_updated_at).toLocaleString("pt-BR")}.`
                        : "Ainda sem nenhuma atualização — defina o saldo inicial em Configurações.")
                    }
                  >
                    {fmtCurrency(pix.funds_balance_amount ?? 0, pix.funds_balance_currency ?? acc.currency)}
                    <span className="ml-1 text-[10px] font-normal text-zinc-400">fundos</span>
                  </td>
                ) : (
                  <td
                    className="px-4 py-2 text-right tabular-nums"
                    title={
                      funds.fromCap
                        ? `Teto de gasto ${fmtCurrency(Number(acc.spend_cap ?? 0) / 100, acc.currency)} − já gasto ${fmtCurrency(Number(acc.amount_spent ?? 0) / 100, acc.currency)} = disponível pra gastar antes de recarregar.`
                        : "Valor acumulado desde a última cobrança (reseta quando a Meta cobra) — não é saldo que sobra, é o que vai ser cobrado."
                    }
                  >
                    {fmtCurrency(funds.amount, acc.currency)}
                    <span className="ml-1 text-[10px] font-normal text-zinc-400">
                      {funds.fromCap ? "disponível" : "a pagar"}
                    </span>
                  </td>
                )}
                <td className="px-4 py-2 text-right tabular-nums">
                  {fmtCurrency(insights[acc.account_id]?.daily_budget, acc.currency)}
                </td>
                <td className="px-4 py-2">
                  {reasons.length > 0 ? (
                    <div className="flex flex-col gap-1">
                      {reasons.map((r) => (
                        <span
                          key={r.key}
                          className={`inline-block w-fit rounded-full px-2 py-0.5 text-xs font-medium ${
                            r.tone === "red"
                              ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300"
                              : "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300"
                          }`}
                        >
                          {r.label}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-zinc-400">—</span>
                  )}
                </td>
                <td className="max-w-[220px] px-4 py-2 text-zinc-600 dark:text-zinc-300">{notes || "—"}</td>
                <td className="px-4 py-2">
                  <div className="flex flex-wrap gap-1.5">
                    {action === "pix" ? (
                      <button
                        onClick={() => onOpenPix(acc)}
                        className="h-7 rounded-md border border-zinc-300 px-2 text-xs font-medium dark:border-zinc-700"
                      >
                        📲 Enviar Pix
                      </button>
                    ) : null}
                    {action === "boleto" ? (
                      <button
                        onClick={() => onOpenBoleto(acc.account_id)}
                        className="h-7 rounded-md border border-zinc-300 px-2 text-xs font-medium dark:border-zinc-700"
                      >
                        🧾 Enviar boleto
                      </button>
                    ) : null}
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// Etapa 63: Controle de Saldo virou um quadro de monitoramento orientado a
// alerta — toda conta selecionada é checada (saldo baixo, sexta-feira de fim
// de semana e erro no pagamento). Etapa 79: reorganizado
// em sub-abas — "Pendências" junta só quem tem algo pendente (qualquer Tipo
// de conta), e Pix/Híbrida/Boleto/Cartão mostram TODAS as contas daquele
// tipo (pendente ou não), pra classificar e acompanhar cada uma. Ajustar
// Tipo de conta, limites e rotinas de cada conta é feito na sub-aba
// "Configurações" (antes era o modal "Personalizar alertas").
export function ControleSaldo({
  accounts,
  clientNames,
  pixByAccount,
  insights,
  onPatch,
  onRefresh,
  refreshing,
}: {
  accounts: AdAccount[];
  clientNames: Record<string, string>;
  pixByAccount: Record<string, PixRow>;
  // Etapa 75: orçamento diário atual (coluna "Invest. diário") — mesmo dado
  // já buscado pra Acompanhamento (insight.daily_budget, independente do
  // período escolhido no filtro de lá), reaproveitado aqui.
  insights: Record<string, AccountInsight>;
  onPatch: (accountId: string, patch: PixPatch) => Promise<void>;
  onRefresh: () => void;
  refreshing: boolean;
}) {
  const [tab, setTab] = useState<TabId>("pendencias");
  const [balanceStatuses, setBalanceStatuses] = useState<BalanceStatus[] | null>(null);
  const [fridayStatuses, setFridayStatuses] = useState<FridayBalanceStatus[] | null>(null);
  const [paymentStatuses, setPaymentStatuses] = useState<PaymentStatus[] | null>(null);
  const [loadingStatuses, setLoadingStatuses] = useState(false);

  // Etapa 71: envio de boleto por e-mail (upload do PDF → dispara pro n8n,
  // que manda de verdade pelo Gmail — ver app/api/boletos/send/route.ts).
  // Etapa 79: o cartão inteiro mudou de lugar, pra dentro da sub-aba Boleto.
  const [boletoAccountId, setBoletoAccountId] = useState("");
  const [boletoDueDate, setBoletoDueDate] = useState("");
  const [boletoFile, setBoletoFile] = useState<{ url: string; fileName: string } | null>(null);
  const [boletoUploading, setBoletoUploading] = useState(false);
  const [boletoSending, setBoletoSending] = useState(false);
  const [boletoMsg, setBoletoMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const boletoFileInputRef = useRef<HTMLInputElement>(null);
  const boletoFormRef = useRef<HTMLDivElement>(null);
  const [boletoHistory, setBoletoHistory] = useState<BoletoSend[] | null>(null);
  const [boletoHistoryOpen, setBoletoHistoryOpen] = useState(false);

  // Etapa 73: envio de Pix por WhatsApp — o botão fica na coluna Ação de cada
  // conta Pix/Híbrida (destino já configurado em Configurações); aqui só
  // guardamos qual conta abriu o modal e o histórico dos últimos envios.
  const [pixDialogAccount, setPixDialogAccount] = useState<{ id: string; clientName: string } | null>(null);
  const [pixHistory, setPixHistory] = useState<PixSend[] | null>(null);
  const [pixHistoryOpen, setPixHistoryOpen] = useState(false);

  // Etapa 124: backup no navegador dos 3 status. Entrar na aba mostra o salvo e só busca (3 consultas à Meta)
  // se não há nada recente (1h); ↻ Atualizar e qualquer ação (verificar, boleto, Pix) buscam de novo (force).
  // Se a Meta falhar, o salvo continua na tela.
  const [statusesAt, setStatusesAt] = useState<number | null>(null);
  const loadStatuses = useCallback(async (force = false) => {
    type Saved = {
      balance: BalanceStatus[];
      friday: FridayBalanceStatus[];
      payment: PaymentStatus[];
    };
    const backup = readTabCache<Saved>("saldo-status");
    if (backup) {
      setBalanceStatuses(backup.data.balance);
      setFridayStatuses(backup.data.friday);
      setPaymentStatuses(backup.data.payment);
      setStatusesAt(backup.at);
      if (!force && isFresh(backup)) return;
    }
    setLoadingStatuses(true);
    try {
      const [balanceRes, fridayRes, paymentRes] = await Promise.all([
        fetch("/api/alerts/balance").then((r) => r.json()),
        fetch("/api/alerts/balance-friday").then((r) => r.json()),
        fetch("/api/alerts/payment").then((r) => r.json()),
      ]);
      const okAll = balanceRes.statuses && fridayRes.statuses && paymentRes.statuses;
      if (!okAll && backup) return; // Meta falhou: mantém o salvo
      setBalanceStatuses(balanceRes.statuses ?? []);
      setFridayStatuses(fridayRes.statuses ?? []);
      setPaymentStatuses(paymentRes.statuses ?? []);
      if (okAll) {
        setStatusesAt(
          writeTabCache<Saved>("saldo-status", {
            balance: balanceRes.statuses,
            friday: fridayRes.statuses,
            payment: paymentRes.statuses,
          }),
        );
      }
    } catch {
      if (!backup) {
        setBalanceStatuses((v) => v ?? []);
        setFridayStatuses((v) => v ?? []);
        setPaymentStatuses((v) => v ?? []);
      }
    } finally {
      setLoadingStatuses(false);
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- carga inicial dos 4 status (usa o backup se recente)
    void loadStatuses(false);
  }, [loadStatuses]);

  async function handleRefresh() {
    onRefresh();
    await loadStatuses(true);
  }

  async function uploadBoleto(file: File) {
    setBoletoUploading(true);
    setBoletoMsg(null);
    const form = new FormData();
    form.append("file", file);
    try {
      const res = await fetch("/api/boletos/upload", { method: "POST", body: form });
      const d = await res.json();
      if (d.error) {
        setBoletoMsg({ ok: false, text: d.error });
      } else {
        setBoletoFile({ url: d.url, fileName: d.fileName });
      }
    } catch {
      setBoletoMsg({ ok: false, text: "Falha ao enviar o PDF." });
    }
    setBoletoUploading(false);
  }

  async function loadBoletoHistory() {
    const res = await fetch("/api/boletos/history").then((r) => r.json());
    setBoletoHistory(res.sends ?? []);
  }

  async function loadPixHistory() {
    const res = await fetch("/api/pix/history").then((r) => r.json());
    setPixHistory(res.sends ?? []);
  }

  async function sendBoleto() {
    if (!boletoAccountId || !boletoDueDate || !boletoFile) return;
    setBoletoSending(true);
    setBoletoMsg(null);
    try {
      const res = await fetch("/api/boletos/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ad_account_id: boletoAccountId,
          due_date: boletoDueDate,
          pdf_url: boletoFile.url,
          pdf_file_name: boletoFile.fileName,
        }),
      });
      const d = await res.json();
      if (d.error) {
        setBoletoMsg({ ok: false, text: d.error });
      } else {
        setBoletoMsg({
          ok: true,
          text: "E-mail disparado — pode conferir no financeiro.",
        });
        setBoletoFile(null);
        setBoletoDueDate("");
        if (boletoFileInputRef.current) boletoFileInputRef.current.value = "";
        if (boletoHistoryOpen) void loadBoletoHistory();
        void loadStatuses(true);
      }
    } catch {
      setBoletoMsg({ ok: false, text: "Falha ao disparar o e-mail." });
    }
    setBoletoSending(false);
  }

  const balanceById = new Map((balanceStatuses ?? []).map((s) => [s.ad_account_id, s]));
  const fridayById = new Map((fridayStatuses ?? []).map((s) => [s.ad_account_id, s]));
  const paymentById = new Map((paymentStatuses ?? []).map((s) => [s.ad_account_id, s]));

  const statusesLoaded = balanceStatuses !== null && fridayStatuses !== null && paymentStatuses !== null;

  // Etapa 96: o formulário de boleto só lista contas com Tipo = Boleto.
  const sortedAccountsForBoleto = accounts
    .filter((a) => pixByAccount[a.account_id]?.payment_type === "boleto")
    .sort((a, b) =>
    (clientNames[a.account_id] ?? a.name).localeCompare(clientNames[b.account_id] ?? b.name, "pt-BR"),
  );

  const allRows: Row[] = accounts
    .map((acc) => {
      const reasons: Reason[] = [];
      const payment = paymentById.get(acc.account_id);
      const balance = balanceById.get(acc.account_id);
      const friday = fridayById.get(acc.account_id);

      if (payment?.hasError) {
        reasons.push({ key: "payment", label: payment.reason ?? "Erro no pagamento", tone: "red" });
      }
      if (balance?.low) {
        reasons.push({
          key: "balance",
          label: `Saldo baixo (${fmtCurrency(balance.balance, balance.currency)} < ${fmtCurrency(balance.threshold, balance.currency)})`,
          tone: "red",
        });
      }
      if (friday?.applicable && friday.low) {
        reasons.push({
          key: "friday",
          label: `Sexta: saldo menor que ${friday.multiplier}x o limite (fim de semana)`,
          tone: "amber",
        });
      }
      return { acc, reasons };
    })
    .sort((a, b) => b.reasons.length - a.reasons.length);

  const pendingRows = allRows.filter((row) => row.reasons.length > 0);
  const rowsByType = (type: string) => allRows.filter((row) => pixByAccount[row.acc.account_id]?.payment_type === type);
  // Contas com "Saldo por fundos" ligado (Pix ou Híbrida) ficam numa subseção própria da aba Pix e saem da lista normal
  // (e da aba Híbrida), pra nenhuma aparecer duas vezes.
  const hasFunds = (row: Row) => !!pixByAccount[row.acc.account_id]?.funds_balance_enabled;
  const fundsRows = allRows.filter((row) => {
    const t = pixByAccount[row.acc.account_id]?.payment_type;
    return (t === "pix" || t === "hybrid") && hasFunds(row);
  });
  const pixRows = rowsByType("pix").filter((row) => !hasFunds(row));
  const hybridRows = rowsByType("hybrid").filter((row) => !hasFunds(row));
  const boletoRows = rowsByType("boleto");
  const cardRows = rowsByType("card");
  const unclassifiedCount = accounts.filter((a) => !pixByAccount[a.account_id]?.payment_type).length;

  function openPixDialog(acc: AdAccount) {
    setPixDialogAccount({ id: acc.account_id, clientName: clientNames[acc.account_id] ?? acc.name });
  }

  // Etapa 120: o botão "Enviar boleto" da linha seleciona o cliente, leva até o formulário e já abre a
  // escolha do PDF (antes só trocava o cliente do formulário e parecia que não fazia nada).
  function openBoletoForm(accountId: string) {
    setTab("boleto");
    setBoletoAccountId(accountId);
    const nome = clientNames[accountId] ?? accounts.find((a) => a.account_id === accountId)?.name ?? "cliente";
    setBoletoMsg({
      ok: true,
      text: `Cliente selecionado: ${nome}. Agora anexe o PDF e escolha o vencimento — depois clique em "Enviar e-mail".`,
    });
    setTimeout(() => {
      boletoFormRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      if (!boletoFile) boletoFileInputRef.current?.click();
    }, 60);
  }

  const contasTableProps = {
    insights,
    clientNames,
    pixByAccount,
    onOpenPix: openPixDialog,
    onOpenBoleto: openBoletoForm,
  };

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 px-4 py-3 dark:border-zinc-800">
        <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-50">
          Controle de Saldo
          {statusesAt && !loadingStatuses ? (
            <span className="ml-2 text-xs font-normal text-zinc-400">· atualizado às {fmtCacheTime(statusesAt)}</span>
          ) : null}
        </h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setPixHistoryOpen((v) => !v);
              if (!pixHistoryOpen && pixHistory === null) void loadPixHistory();
            }}
            className="h-8 rounded-md border border-zinc-300 px-2.5 text-sm font-medium dark:border-zinc-700"
          >
            {pixHistoryOpen ? "Ocultar histórico de Pix" : "📲 Histórico de Pix"}
          </button>
          <button
            onClick={() => void handleRefresh()}
            disabled={refreshing || loadingStatuses}
            className="h-8 rounded-md border border-zinc-300 px-2.5 text-sm font-medium disabled:opacity-50 dark:border-zinc-700"
          >
            {refreshing || loadingStatuses ? "Atualizando…" : "↻ Atualizar"}
          </button>
        </div>
      </div>

      <p className="border-b border-zinc-100 px-4 py-2 text-xs text-zinc-500 dark:border-zinc-800/60 dark:text-zinc-400">
        Pendências junta quem tem algum aviso agora, de qualquer Tipo de conta. Os subgrupos Pix/Híbrida/Boleto/Cartão
        mostram todas as contas daquele tipo, com ou sem aviso. Classifique o Tipo de conta e ajuste limites e rotinas
        em &quot;Configurações&quot;.
      </p>

      {/* Etapa 79: abas — Pendências primeiro (cai aqui ao abrir a tela), um
          subgrupo por Tipo de conta na ordem pedida, e Configurações por
          último. */}
      <div className="flex flex-wrap gap-1 border-b border-zinc-200 px-4 py-2 dark:border-zinc-800">
        {TABS.map((t) => {
          const count =
            t.id === "pendencias"
              ? pendingRows.length
              : t.id === "pix"
                ? pixRows.length + fundsRows.length
                : t.id === "hybrid"
                  ? hybridRows.length
                  : t.id === "boleto"
                    ? boletoRows.length
                    : t.id === "card"
                      ? cardRows.length
                      : unclassifiedCount;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                tab === t.id
                  ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
                  : "text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
              }`}
            >
              {t.label}
              {count > 0 ? (
                <span
                  className={`ml-1.5 rounded-full px-1.5 py-0.5 text-[10px] ${
                    tab === t.id ? "bg-white/20" : "bg-zinc-200 dark:bg-zinc-700"
                  }`}
                >
                  {count}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Etapa 73: histórico de Pix — o envio em si acontece pelo botão
          "Enviar Pix" na coluna Ação de cada conta Pix/Híbrida (o destino já
          vem configurado em Configurações). Ver app/api/pix/*. Fica visível
          em qualquer aba, não só nas de Pix/Híbrida. */}
      {pixHistoryOpen ? (
        <div className="border-b border-zinc-200 px-4 py-3 dark:border-zinc-800">
          <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-50">📲 Histórico de Pix</h3>
          <div className="mt-2 overflow-x-auto rounded-md border border-zinc-200 dark:border-zinc-800">
            {pixHistory === null ? (
              <p className="px-3 py-2 text-xs text-zinc-500">Carregando…</p>
            ) : pixHistory.length === 0 ? (
              <p className="px-3 py-2 text-xs text-zinc-500">Nenhum envio ainda.</p>
            ) : (
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left uppercase tracking-wide text-zinc-400">
                    <th className="px-3 py-1 font-medium">Loja</th>
                    <th className="px-3 py-1 font-medium">Destino</th>
                    <th className="px-3 py-1 font-medium">Status</th>
                    <th className="px-3 py-1 font-medium">Agendado para</th>
                    <th className="px-3 py-1 font-medium">Quando</th>
                  </tr>
                </thead>
                <tbody>
                  {pixHistory.map((s) => (
                    <tr key={s.id} className="border-t border-zinc-100 dark:border-zinc-800/60">
                      <td className="px-3 py-1.5">{s.client_name}</td>
                      <td className="max-w-[160px] truncate px-3 py-1.5">
                        {s.target_type === "numero" ? "Número" : "Grupo"}: {s.target_label || "—"}
                      </td>
                      <td className="px-3 py-1.5">
                        {s.status === "sent" ? (
                          <span className="text-emerald-600 dark:text-emerald-400">Enviado</span>
                        ) : s.status === "error" ? (
                          <span title={s.error ?? ""} className="text-red-600">
                            Erro
                          </span>
                        ) : s.status === "scheduled" ? (
                          <span className="text-zinc-500">Programado</span>
                        ) : (
                          <span className="text-zinc-500">Pendente</span>
                        )}
                      </td>
                      <td className="px-3 py-1.5 text-zinc-500">
                        {s.scheduled_at ? new Date(s.scheduled_at).toLocaleString("pt-BR") : "—"}
                      </td>
                      <td className="px-3 py-1.5 text-zinc-500">{new Date(s.created_at).toLocaleString("pt-BR")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      ) : null}

      {accounts.length === 0 ? (
        <p className="px-4 py-6 text-sm text-zinc-500">Nenhuma conta selecionada.</p>
      ) : tab === "pendencias" ? (
        !statusesLoaded ? (
          <p className="px-4 py-6 text-sm text-zinc-500">Carregando…</p>
        ) : (
          <ContasTable
            rows={pendingRows}
            emptyMessage="✅ Tudo certo — nenhuma conta pendente ou com aviso agora."
            {...contasTableProps}
          />
        )
      ) : tab === "pix" ? (
        <div>
          <h3 className="px-4 pt-3 text-sm font-semibold text-zinc-900 dark:text-zinc-50">
            Pix <span className="text-xs font-normal text-zinc-400">· {pixRows.length}</span>
          </h3>
          <ContasTable
            rows={pixRows}
            emptyMessage="Nenhuma conta classificada como Pix (sem saldo por fundos) — veja em Configurações."
            {...contasTableProps}
          />
          <div className="mt-2 border-t border-zinc-200 dark:border-zinc-800">
            <h3 className="px-4 pt-3 text-sm font-semibold text-zinc-900 dark:text-zinc-50">
              Saldo por fundos <span className="text-xs font-normal text-zinc-400">· {fundsRows.length}</span>
            </h3>
            <p className="px-4 pt-1 text-xs text-zinc-500 dark:text-zinc-400">
              Contas (Pix ou Híbrida) com &quot;Saldo por fundos&quot; ligado em Configurações — o saldo mostrado é o dos fundos
              (saldo inicial + Pix − cobranças da Meta), não o da Meta.
            </p>
            <ContasTable
              rows={fundsRows}
              emptyMessage="Nenhuma conta com Saldo por fundos ligado — ative em Configurações."
              {...contasTableProps}
            />
          </div>
        </div>
      ) : tab === "hybrid" ? (
        <ContasTable
          rows={hybridRows}
          emptyMessage="Nenhuma conta Híbrida (sem saldo por fundos) — as com fundos ficam em Pix → Saldo por fundos."
          {...contasTableProps}
        />
      ) : tab === "boleto" ? (
        <div>
          {/* Etapa 71: envio de boleto por e-mail — sobe o PDF, escolhe
              cliente e vencimento, e dispara o e-mail padrão pro financeiro
              (texto fixo, só troca loja/data/anexo). Ver app/api/boletos/*.
              Etapa 79: mudou pra dentro da sub-aba Boleto; o botão "Enviar
              boleto" de cada linha da tabela abaixo só seleciona a conta
              aqui, quem sobe o PDF e dispara é esse formulário mesmo. */}
          <div ref={boletoFormRef} className="border-b border-zinc-200 px-4 py-3 dark:border-zinc-800">
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-50">📧 Enviar boleto por e-mail</h3>
            <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
              Sobe o boleto em PDF e dispara o e-mail padrão pro financeiro — só troca a loja e o vencimento.
            </p>
            <div className="mt-3 flex flex-wrap items-end gap-2">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-zinc-500">Cliente</label>
                <select
                  value={boletoAccountId}
                  onChange={(e) => setBoletoAccountId(e.target.value)}
                  className="h-8 min-w-[220px] rounded-md border border-zinc-300 bg-transparent px-2 text-sm dark:border-zinc-700"
                >
                  <option value="">Selecione…</option>
                  {sortedAccountsForBoleto.map((acc) => (
                    <option key={acc.account_id} value={acc.account_id}>
                      {clientNames[acc.account_id] ?? acc.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-zinc-500">Vencimento</label>
                <input
                  type="date"
                  value={boletoDueDate}
                  onChange={(e) => setBoletoDueDate(e.target.value)}
                  className="h-8 rounded-md border border-zinc-300 bg-transparent px-2 text-sm dark:border-zinc-700"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-zinc-500">Boleto (PDF)</label>
                <input
                  ref={boletoFileInputRef}
                  type="file"
                  accept="application/pdf,.pdf"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void uploadBoleto(f);
                  }}
                />
                {boletoFile ? (
                  <span className="flex h-8 items-center gap-2 rounded-md border border-zinc-300 px-2 text-xs dark:border-zinc-700">
                    📎 <span className="max-w-[160px] truncate">{boletoFile.fileName}</span>
                    <button
                      onClick={() => {
                        setBoletoFile(null);
                        if (boletoFileInputRef.current) boletoFileInputRef.current.value = "";
                      }}
                      className="font-medium text-red-600"
                    >
                      Remover
                    </button>
                  </span>
                ) : (
                  <button
                    onClick={() => boletoFileInputRef.current?.click()}
                    disabled={boletoUploading}
                    className="h-8 rounded-md border border-zinc-300 px-2.5 text-xs font-medium disabled:opacity-60 dark:border-zinc-700"
                  >
                    {boletoUploading ? "Enviando…" : "📎 Anexar PDF"}
                  </button>
                )}
              </div>
              <button
                onClick={() => void sendBoleto()}
                disabled={boletoSending || boletoUploading || !boletoAccountId || !boletoDueDate || !boletoFile}
                className="h-8 rounded-md bg-zinc-900 px-3 text-sm font-medium text-white disabled:opacity-50 dark:bg-zinc-100 dark:text-zinc-900"
              >
                {boletoSending ? "Enviando…" : "Enviar e-mail"}
              </button>
              <button
                onClick={() => {
                  setBoletoHistoryOpen((v) => !v);
                  if (!boletoHistoryOpen && boletoHistory === null) void loadBoletoHistory();
                }}
                className="h-8 rounded-md border border-zinc-300 px-2.5 text-xs font-medium dark:border-zinc-700"
              >
                {boletoHistoryOpen ? "Ocultar histórico" : "Ver histórico"}
              </button>
            </div>
            {!boletoMsg && (!boletoAccountId || !boletoDueDate || !boletoFile) ? (
              <p className="mt-2 text-xs text-zinc-500 dark:text-zinc-400">
                Pra liberar o "Enviar e-mail", falta:{" "}
                {[!boletoAccountId && "escolher o cliente", !boletoFile && "anexar o PDF", !boletoDueDate && "escolher o vencimento"]
                  .filter(Boolean)
                  .join(", ")}
                .
              </p>
            ) : null}
            {boletoMsg ? (
              <p
                className={`mt-2 text-xs font-medium ${
                  boletoMsg.ok ? "text-emerald-600 dark:text-emerald-400" : "text-red-600"
                }`}
              >
                {boletoMsg.text}
              </p>
            ) : null}
            {boletoHistoryOpen ? (
              <div className="mt-3 overflow-x-auto rounded-md border border-zinc-200 dark:border-zinc-800">
                {boletoHistory === null ? (
                  <p className="px-3 py-2 text-xs text-zinc-500">Carregando…</p>
                ) : boletoHistory.length === 0 ? (
                  <p className="px-3 py-2 text-xs text-zinc-500">Nenhum envio ainda.</p>
                ) : (
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left uppercase tracking-wide text-zinc-400">
                        <th className="px-3 py-1 font-medium">Loja</th>
                        <th className="px-3 py-1 font-medium">Vencimento</th>
                        <th className="px-3 py-1 font-medium">Arquivo</th>
                        <th className="px-3 py-1 font-medium">Status</th>
                        <th className="px-3 py-1 font-medium">Quando</th>
                      </tr>
                    </thead>
                    <tbody>
                      {boletoHistory.map((s) => (
                        <tr key={s.id} className="border-t border-zinc-100 dark:border-zinc-800/60">
                          <td className="px-3 py-1.5">{s.client_name}</td>
                          <td className="px-3 py-1.5">{fmtDateBR(s.due_date)}</td>
                          <td className="max-w-[160px] truncate px-3 py-1.5">{s.pdf_file_name || "—"}</td>
                          <td className="px-3 py-1.5">
                            {s.status === "sent" ? (
                              <span className="text-emerald-600 dark:text-emerald-400">Enviado</span>
                            ) : s.status === "error" ? (
                              <span title={s.error ?? ""} className="text-red-600">
                                Erro
                              </span>
                            ) : (
                              <span className="text-zinc-500">Pendente</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 text-zinc-500">{new Date(s.created_at).toLocaleString("pt-BR")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            ) : null}
          </div>
          <ContasTable
            rows={boletoRows}
            emptyMessage="Nenhuma conta classificada como Boleto ainda — veja em Configurações."
            {...contasTableProps}
          />
        </div>
      ) : tab === "card" ? (
        <ContasTable
          rows={cardRows}
          emptyMessage="Nenhuma conta classificada como Cartão ainda — veja em Configurações."
          {...contasTableProps}
        />
      ) : (
        <PersonalizarAlertasPanel accounts={accounts} clientNames={clientNames} pixByAccount={pixByAccount} onPatch={onPatch} />
      )}

      <EnviarPixDialog
        open={pixDialogAccount !== null}
        onClose={() => setPixDialogAccount(null)}
        accountId={pixDialogAccount?.id ?? ""}
        clientName={pixDialogAccount?.clientName ?? ""}
        pixRow={pixDialogAccount ? pixByAccount[pixDialogAccount.id] : undefined}
        onSent={() => {
          if (pixHistoryOpen) void loadPixHistory();
          void loadStatuses(true);
        }}
      />
    </div>
  );
}
