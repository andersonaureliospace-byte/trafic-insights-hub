// Checagem de saldo baixo — usada tanto pela rota "Verificar agora" (sessão
// do usuário, em Mensagens > Avisos) quanto pelo hook público
// balance-alert-tick (service role, chamado pelo n8n). Só considera contas
// Pix/Híbrida (Boleto e Cartão não ficam sem saldo, são cobradas depois) que
// tenham um limite definido (explícito em alert_threshold, ou 20% do
// "Valor base" como padrão). Etapa 79: payment_type agora é 'pix'/'hybrid'/
// 'boleto'/'card' (ou null, sem tipo definido ainda) — ver
// supabase/migrations/0024_*.

import type { createClient } from "@/lib/supabase/server";
import { getAdAccounts } from "@/lib/meta/insights";
import { availableFunds } from "@/lib/meta/funds";
import { getRecentSends } from "@/lib/alerts/recent-sends";
import { publishAlert } from "@/lib/alerts/notifications";
import { fmtCurrency } from "@/lib/format";

import { inactiveAccountIds } from "@/lib/accounts/inactive";
type Db = Awaited<ReturnType<typeof createClient>>;

// Etapa 95: saldo usado nos avisos. Conta com "Saldo por fundos" ligado (Etapa 81, ex.:
// Híbrida) usa esse valor — o mesmo que aparece na coluna Saldo da tela — e não o
// `balance` bruto da Meta (valor a pagar), que nessas contas é baixo mesmo com fundos
// de sobra (ex.: R$ 50,08 de "a pagar" contra R$ 1.002,43 de fundos).
export function effectiveBalance(
  acc: Parameters<typeof availableFunds>[0],
  p: { funds_balance_enabled?: boolean | null; funds_balance_amount?: number | null },
): number {
  if (p.funds_balance_enabled && p.funds_balance_amount != null) return Number(p.funds_balance_amount);
  return availableFunds(acc).amount;
}

const COOLDOWN_MS = 24 * 60 * 60 * 1000; // não reavisa a mesma conta antes de 24h

export interface BalanceStatus {
  ad_account_id: string;
  client_name: string;
  balance: number;
  currency: string;
  threshold: number;
  low: boolean;
  // Etapa 96: Pix/boleto enviado nos últimos 30 min — o aviso fica oculto (low = false).
  handled: boolean;
  alerted: boolean;
}

export interface CheckLowBalancesResult {
  statuses: BalanceStatus[];
  // Etapa 38: antes esse erro era engolido em silêncio (instância do
  // WhatsApp não configurada, grupo de avisos não definido, ou falha de
  // envio no uazapi) — o "Verificar agora" voltava como se tivesse dado
  // tudo certo mesmo sem mandar nada. Agora fica aqui pra tela mostrar de
  // verdade o que impediu o envio, sem esconder a tabela de status.
  sendError: string | null;
}

export async function checkLowBalances(
  db: Db,
  userId: string,
  token: string,
  opts: { send: boolean; bypassCooldown?: boolean } = { send: false },
): Promise<CheckLowBalancesResult> {
  const off = await inactiveAccountIds(db, userId);
  const { data: pixRows, error: pixErr } = await db
    .from("pix_accounts")
    .select(
      "ad_account_id, payment_type, base_amount, alert_threshold, last_alert_sent_at, funds_balance_enabled, funds_balance_amount",
    )
    .eq("user_id", userId)
    .in("payment_type", ["pix", "hybrid"]);
  if (pixErr) throw pixErr;
  const withThreshold = (pixRows ?? []).filter(
    (p) => p.alert_threshold != null || p.base_amount != null,
  );
  if (withThreshold.length === 0) return { statuses: [], sendError: null };

  const { data: bindings } = await db
    .from("account_bindings")
    .select("ad_account_id, client_name")
    .eq("user_id", userId);
  const clientNameById = new Map((bindings ?? []).map((b) => [b.ad_account_id as string, b.client_name as string]));

  const accounts = await getAdAccounts(token);
  const accountById = new Map(accounts.map((a) => [a.account_id, a]));

  const recent = await getRecentSends(db, userId);
  const statuses: BalanceStatus[] = [];
  const toAlert: BalanceStatus[] = [];
  const toReset: string[] = [];

  for (const p of withThreshold) {
    if (off.has(p.ad_account_id as string)) continue; // Etapa 131: cliente desativado
    const acc = accountById.get(p.ad_account_id);
    if (!acc) continue;
    const threshold = (p.alert_threshold as number | null) ?? Number(p.base_amount) * 0.2;
    const balance = effectiveBalance(acc, p);
    const handled = recent.pix.has(p.ad_account_id) || recent.boleto.has(p.ad_account_id);
    const low = balance < threshold && !handled;
    const clientName = clientNameById.get(p.ad_account_id) || acc.name;
    const withinCooldown =
      !opts.bypassCooldown &&
      !!p.last_alert_sent_at &&
      Date.now() - new Date(p.last_alert_sent_at).getTime() < COOLDOWN_MS;

    const status: BalanceStatus = {
      ad_account_id: p.ad_account_id,
      client_name: clientName,
      balance,
      currency: acc.currency,
      threshold,
      low,
      handled,
      alerted: false,
    };
    statuses.push(status);

    if (low && !withinCooldown) {
      toAlert.push(status);
    } else if (!low && !handled && p.last_alert_sent_at) {
      toReset.push(p.ad_account_id);
    }
  }

  let sendError: string | null = null;
  if (opts.send && toAlert.length > 0) {
    try {
      const lines = toAlert.map(
        (s) => `⚠️ ${s.client_name}: saldo ${fmtCurrency(s.balance, s.currency)} (limite ${fmtCurrency(s.threshold, s.currency)})`,
      );
      await publishAlert(db, userId, {
        kind: "balance-low",
        title: "Aviso de saldo baixo",
        body: lines.join("\n"),
        count: toAlert.length,
      });
      const now = new Date().toISOString();
      for (const s of toAlert) {
        s.alerted = true;
        await db.from("pix_accounts").update({ last_alert_sent_at: now }).eq("user_id", userId).eq("ad_account_id", s.ad_account_id);
      }
    } catch (e) {
      // Antes isso era descartado sem deixar rastro — agora sobe pra quem
      // chamou decidir o que mostrar (tela ou log do hook do n8n).
      sendError = (e as Error).message;
    }
  }

  if (toReset.length > 0) {
    await db
      .from("pix_accounts")
      .update({ last_alert_sent_at: null })
      .eq("user_id", userId)
      .in("ad_account_id", toReset);
  }

  return { statuses, sendError };
}

// Etapa 63: checagem extra de sexta-feira — Pix/Híbrida com um
// multiplicador configurado (2x ou 3x) ficam "em alerta de fim de semana"
// quando o saldo disponível está abaixo de limite × multiplicador, mesmo que
// ainda não tenha cruzado o limite normal do checkLowBalances acima. Só faz
// sentido numa sexta-feira (fuso America/Sao_Paulo) — nos outros dias
// `applicable` vem false pra toda conta e nada é considerado baixo. Cooldown
// de 24h próprio (friday_alert_sent_at), separado do saldo baixo comum.
function isFridaySP(d: Date = new Date()): boolean {
  const weekday = new Intl.DateTimeFormat("en-US", { timeZone: "America/Sao_Paulo", weekday: "short" }).format(d);
  return weekday === "Fri";
}

export interface FridayBalanceStatus {
  ad_account_id: string;
  client_name: string;
  balance: number;
  currency: string;
  threshold: number;
  multiplier: number;
  fridayThreshold: number;
  applicable: boolean;
  low: boolean;
  handled: boolean;
  alerted: boolean;
}

export interface CheckFridayLowBalancesResult {
  statuses: FridayBalanceStatus[];
  sendError: string | null;
}

export async function checkFridayLowBalances(
  db: Db,
  userId: string,
  token: string,
  opts: { send: boolean; bypassCooldown?: boolean } = { send: false },
): Promise<CheckFridayLowBalancesResult> {
  const applicable = isFridaySP();

  const off = await inactiveAccountIds(db, userId);
  const { data: pixRows, error: pixErr } = await db
    .from("pix_accounts")
    .select(
      "ad_account_id, payment_type, base_amount, alert_threshold, friday_multiplier, friday_alert_sent_at, funds_balance_enabled, funds_balance_amount",
    )
    .eq("user_id", userId)
    .in("payment_type", ["pix", "hybrid"])
    .not("friday_multiplier", "is", null);
  if (pixErr) throw pixErr;
  if (!pixRows || pixRows.length === 0) return { statuses: [], sendError: null };

  const { data: bindings } = await db
    .from("account_bindings")
    .select("ad_account_id, client_name")
    .eq("user_id", userId);
  const clientNameById = new Map((bindings ?? []).map((b) => [b.ad_account_id as string, b.client_name as string]));

  const accounts = await getAdAccounts(token);
  const accountById = new Map(accounts.map((a) => [a.account_id, a]));

  const recent = await getRecentSends(db, userId);
  const statuses: FridayBalanceStatus[] = [];
  const toAlert: FridayBalanceStatus[] = [];
  const toReset: string[] = [];

  for (const p of pixRows) {
    if (off.has(p.ad_account_id as string)) continue; // Etapa 131: cliente desativado
    const acc = accountById.get(p.ad_account_id);
    if (!acc) continue;
    const threshold = (p.alert_threshold as number | null) ?? (p.base_amount != null ? Number(p.base_amount) * 0.2 : 0);
    const multiplier = Number(p.friday_multiplier);
    const fridayThreshold = threshold * multiplier;
    const balance = effectiveBalance(acc, p);
    const handled = recent.pix.has(p.ad_account_id) || recent.boleto.has(p.ad_account_id);
    const low = applicable && fridayThreshold > 0 && balance < fridayThreshold && !handled;
    const clientName = clientNameById.get(p.ad_account_id) || acc.name;
    const withinCooldown =
      !opts.bypassCooldown &&
      !!p.friday_alert_sent_at &&
      Date.now() - new Date(p.friday_alert_sent_at).getTime() < COOLDOWN_MS;

    const status: FridayBalanceStatus = {
      ad_account_id: p.ad_account_id,
      client_name: clientName,
      balance,
      currency: acc.currency,
      threshold,
      multiplier,
      fridayThreshold,
      applicable,
      low,
      handled,
      alerted: false,
    };
    statuses.push(status);

    if (low && !withinCooldown) {
      toAlert.push(status);
    } else if (!low && !handled && p.friday_alert_sent_at) {
      toReset.push(p.ad_account_id);
    }
  }

  let sendError: string | null = null;
  if (opts.send && toAlert.length > 0) {
    try {
      const lines = toAlert.map(
        (s) =>
          `⚠️ ${s.client_name}: saldo ${fmtCurrency(s.balance, s.currency)} (menos de ${s.multiplier}x o limite de ${fmtCurrency(s.threshold, s.currency)} — cuidado com o fim de semana)`,
      );
      await publishAlert(db, userId, {
        kind: "balance-friday",
        title: "Aviso de saldo baixo para o fim de semana",
        body: lines.join("\n"),
        count: toAlert.length,
      });
      const now = new Date().toISOString();
      for (const s of toAlert) {
        s.alerted = true;
        await db.from("pix_accounts").update({ friday_alert_sent_at: now }).eq("user_id", userId).eq("ad_account_id", s.ad_account_id);
      }
    } catch (e) {
      sendError = (e as Error).message;
    }
  }

  if (toReset.length > 0) {
    await db
      .from("pix_accounts")
      .update({ friday_alert_sent_at: null })
      .eq("user_id", userId)
      .in("ad_account_id", toReset);
  }

  return { statuses, sendError };
}
